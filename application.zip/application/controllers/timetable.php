<?php
class timetable extends framework{
    public function __construct(){
        if(!$this->getSession('userid')){
            $this->redirect("credential");
        }
        $this->helper("link");
    }
    public function index(){
        $this->view("timetable/dashboard");
    }
    public function class_period(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/class_period",$myModel);
    }
    public function subject_wise_teacher(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/subject_wise_teacher",$myModel);
    }
    public function preferred_teacher_class(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/preferred_teacher_class",$myModel);
    }
    public function manage(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/timetable",$myModel);
    }
    public function refress(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/timetable",$myModel);
    }
    public function ajaxn(){
        $data=[
            'id'       =>$this->input("id"),
            'clases'   =>$this->input("name"),
            'clstcrid' =>$this->input("clstcrid"),
            'section' =>$this->input("section")
        ];
        $myModel=$this->model("userModel");
        $this->view2("ajax/updatetimetable",$myModel,$data);
    }
    public function save_timetable($ifm){
        $myModel=$this->model("userModel");
        for($i=1;$i<=$ifm;$i++){
            $data=[
                explode(",", $this->input("tmon".$i))[0],
                explode(",", $this->input("mon".$i))[0],
                explode(",", $this->input("tmon".$i))[1],
                explode(",", $this->input("mon".$i))[1],
                explode(",", $this->input("ttus".$i))[0],
                explode(",", $this->input("tus".$i))[0],
                explode(",", $this->input("ttus".$i))[1],
                explode(",", $this->input("tus".$i))[1],
                explode(",", $this->input("twed".$i))[0],
                explode(",", $this->input("wed".$i))[0],
                explode(",", $this->input("twed".$i))[1],
                explode(",", $this->input("wed".$i))[1],
                explode(",", $this->input("tthu".$i))[0],
                explode(",", $this->input("thu".$i))[0],
                explode(",", $this->input("tthu".$i))[1],
                explode(",", $this->input("thu".$i))[1],
                explode(",", $this->input("tfri".$i))[0],
                explode(",", $this->input("fri".$i))[0],
                explode(",", $this->input("tfri".$i))[1],
                explode(",", $this->input("fri".$i))[1],
                explode(",", $this->input("tsut".$i))[0],
                explode(",", $this->input("sut".$i))[0],
                explode(",", $this->input("tsut".$i))[1],
                explode(",", $this->input("sut".$i))[1],
                $this->getSession('userid'),
                $this->input("classid"),
                $this->input("timing".$i)
            ];

            if($this->input("update".$i)=="1"){$myData= $myModel->update_timetable($data);}
            else{$myData= $myModel->save_timetable($data);}
        }
        $clth=$this->input("classteacher");
        if(explode(",", $clth)[0] != explode(",", $clth)[1]){
            $myModel->update_classteacher([explode(",", $clth)[1],explode(",", $clth)[2],$this->input("classid")]);
        }

        if($myData){
            echo "Succesfully Save Time Table";
        }
        else{echo "Error";}
    }

    function add_class_period(){
        $myModel=$this->model("userModel");
        $myData=$myModel->add_class_period([$this->getSession('userid'),$this->input('priod'),$this->input('start'),$this->input('end')]);
        if($myData){
            $this->view2("ajax/allsubjects",$myModel,['wid'=>"5"]);
        }
        else{echo "Error";}
    }
    function update_class_period(){
        $myModel=$this->model("userModel");
        $myData=$myModel->update_class_period([$this->input('priod'),$this->input('start'),$this->input('end'),$this->input('subid')]);
        if($myData){
            $this->view2("ajax/allsubjects",$myModel,['wid'=>"5"]);
        }
        else{echo "Error";}
    }
    function delete_class_period(){
        $myModel=$this->model("userModel");
        $myData=$myModel->delete_class_period([$this->input('id')]);
        if($myData){
            $this->view2("ajax/allsubjects",$myModel,['wid'=>"5"]);
        }
        else{echo "Error";}
    }
    function show_tchr_data(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"6",'tchrid'=>$this->input('tchrid'),'subid'=>$this->input('subjid'),'tchrname'=>$this->input('tchrname')]);
    }
    function update_tchr_data(){
        $myModel=$this->model("userModel");
        $myData=$myModel->update_tchr_data([$this->input('newdata'),$this->input('tchrid')]);
        if($myData){
            $this->view2("ajax/allsubjects",$myModel,['wid'=>"6",'tchrid'=>$this->input('tchrid'),'subid'=>$this->input('newdata'),'tchrname'=>$this->input('tchrname')]);
        }
        else{echo "Error";}
    }
    function show_tchrs_data(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"7"]);
    }
    function show_tchr_class_data(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"9",'tchrid'=>$this->input('tchrid'),'subid'=>$this->input('subjid'),'tchrname'=>$this->input('tchrname')]);
    }
    function update_tchr_class_data(){
        $myModel=$this->model("userModel");
        $myData=$myModel->update_tchr_class_data([$this->input('newdata'),$this->input('tchrid')]);
        if($myData){
            $this->view2("ajax/allsubjects",$myModel,['wid'=>"9",'tchrid'=>$this->input('tchrid'),'subid'=>$this->input('newdata'),'tchrname'=>$this->input('tchrname')]);
        }
        else{echo "Error";}
    }
    function show_tchrs_class_data(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"8"]);
    }
    function teacher_wise_timetable(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/teacher_wise_timetable",$myModel);
    }
    function day_wise_timetable(){
        $myModel=$this->model("userModel");
        $this->view2("timetable/day_wise_timetable",$myModel);
    }
    function teacher_timetable(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"10",'tcrid'=>$this->input('tcrid')]);
    }
    function day_timetable(){
        $myModel=$this->model("userModel");
        $this->view2("ajax/allsubjects",$myModel,['wid'=>"11",'tcrid'=>$this->input('tcrid')]);
    }
}