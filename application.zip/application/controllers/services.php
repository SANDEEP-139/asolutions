<?php
class services extends framework{
    public function __construct(){
        if(!$this->getSession('userid')){
            $this->redirect("");
        }
        $this->helper("link");
    }
    public function index(){
        $this->view("services/dashboard");
    }
    public function gallery(){
        $this->view("services/gallery");
    }
    public function sms(){
        $this->view("services/sms");
    }
    public function complaints($type){
        $myModel=$this->model("userModel");
        $this->view2("services/student_complaints",$myModel,[$type]);
    }

}
?>