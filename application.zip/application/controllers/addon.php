<?php
class addon extends framework{
    public function __construct(){
        if(!$this->getSession('userid')){
            $this->redirect("");
        }
        $this->helper("link");
    }
    public function index(){
        $this->view("addon/dashboard");
    }
    public function hostel(){
        $this->view("addon/hostel");
    }
    public function library(){
        $this->view("addon/library");
    }
    public function stock(){
        $this->view("addon/stock");
    }
}
?>