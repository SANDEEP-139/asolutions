<footer class="footer-wrap-layout1">
    <div class="copyright">© Copyrights 2019. All rights reserved. Designed by <a href="https://aeromus.com/">Aeromus Technology Private Limited</a></div>
</footer>