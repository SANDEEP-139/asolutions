<?php include "components/header.php"; ?>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area aeroheader2">
                    <h3>SMS Management</h3>
                </div>
                <!-- Breadcubs Area End Here -->
            
                <div class="row gutters-20">
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/registration">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-crowd-of-users text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/registration_list">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-multiple-users-silhouette text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Staff</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/mainegment">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-calendar-22 text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Attendance</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/profile_update">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-profit text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Fee</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/mapping_data_update">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-confetti text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Birthday</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/photo_update">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-gmail text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number">SMS</div>
                                        <div class="item-title">Template</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/contact_update">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-connected-user text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Add</span></div>
                                        <div class="item-title">Group</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>

                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/web_sms">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-employees text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Add Group</span></div>
                                        <div class="item-title">Staff</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/assign_rfid_card">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-crowd-of-users text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Group</span></div>
                                        <div class="item-title">Student</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/roll_no_generate">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-family text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number">Group</div>
                                        <div class="item-title">Teacher</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/student_id_generate">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-class text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Group</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>

                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/guardian_id_generate">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-shield text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Delivery</span></div>
                                        <div class="item-title">Report</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/father_id_generate">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-school-bus-front-with-passengers text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Bus</span></div>
                                        <div class="item-title">SMS</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/mother_id_generate">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-staff-people-group-in-a-circular-arrow text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number">Group Other</div>
                                        <div class="item-title">Contact</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>/student/medical_fitness">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-call text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Voice</span></div>
                                        <div class="item-title">Call</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>

            </div>


<?php include "components/footer.php"; ?>