

<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Teacher Wise Time Table</h3>
    </div>
    <!-- Breadcubs Area End Here -->

    
    <div class="card account-settings-box height-auto">
                <div class="card-body">
                    <div class="heading-layout1 mg-b-20">
                    <div class="row w-100">
                        <div class="col-xl-3 col-sm-6 col-12">
                            <select id="subjecttype" class="select2">
                                <option value="0">Select Teacher</option>
                                <?php 
                                $data= $myModel->select_teacher($this->getSession('userid'));
                                foreach($data as $user):
                                ?>
                                <option value="<?php echo $user->id.','.$user->employee_name; ?>"><?php echo $user->employee_name; ?></option>
                                <?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                    </div>
                    </div>
                    
                    
            <div class="artmbody">
                <!-- <div class="artmchldhead arradius">
                    LKG
                </div> -->
                <table class="table display data-table armg10">
                    <thead>
                        <tr>
                            <th>Class Time</th>
                            <th>Monday</th>
                            <th>Tuesday</th>
                            <th>Wednesday</th>
                            <th>Thursday</th>
                            <th>Friday</th>
                            <th>Saturday</th>
                        </tr>
                    </thead>
                    <tbody id="cldata">
                        <tr>
                        <td colspan="7" class="text-center text-light-sea-green font-bold m-10 arempty">Please Select Teacher</td>
                        </tr>
                    </tbody>
                </table>
                <div class="arclear"></div>
            </div>
                </div>
            </div>
    
</div>

<?php include "components/footer.php"; ?>

<script>
$("#subjecttype").change(function() {
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/teacher_timetable/'?>", 
        type: "POST",
        beforeSend:function(){$("#loadingProgressG").show();},
        data: {tcrid:$(this).val().split(',')[0]},
        success: function(result){
            $("#cldata").html(result);
            $("#loadingProgressG").hide();
        }
    });
});

</script>

