<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Time Table Managment</h3>

    </div>
    <!-- Breadcubs Area End Here -->
    
    <div id="showdata"> </div>
    <div id="timbody" class="card height-auto">
        <?php
            $this->view2("ajax/timetable",$myModel);
        ?>
    </div>
    
    
    
    <!-- Footer Area Start Here -->
    <?php include "components/copyright.php"; ?>
    <!-- Footer Area End Here -->

</div>
<?php include "components/footer.php"; ?>
<script>
function allertrady($corceid,$name,$clstcrid,$section){
    $.ajax({
        url: "<?php echo BASEURL ?>/timetable/ajaxn", 
        type: "POST",
        beforeSend:function(){$("#loadingProgressG").show();},
        data: {id:$corceid,name:$name,clstcrid:$clstcrid,section:$section},
         success: function(result){
           $("#showdata").html(result).show();
           $("#loadingProgressG").hide();
         }
     });

}

</script>