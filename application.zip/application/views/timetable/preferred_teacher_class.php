

<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Class wise teacher</h3>
    </div>
    <!-- Breadcubs Area End Here -->
    
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Subject Teacher</h3>
                </div>
            </div>

            

            <div class="table-responsive">
                <table class="table display data-table">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Teacher Name</th>
                            <th>Class Preferred</th>
                            <th class="text-center">Update</th>
                        </tr>
                    </thead>
                    <tbody id="maindata">
                    <?php
                       $this->view2("ajax/allsubjects",$myModel,['wid'=>"8"]);
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div id="myModal" class="modal">
  <div class="modal-content arwidth1000">
    <span class="close"><i class="fas fa-times-circle"></i></span>
    <h3 id="heading">Subject wise Teacher</h3>
    <hr>
    <div class="row" id="showdatas">
        
    </div>
  </div>
</div>
<?php include "components/footer.php"; ?>


<script>
function showdata($tchrid,$subjid,$tchrname) {
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/show_tchr_class_data/'?>",
        type: "POST",
        data: {tchrid:$tchrid,subjid:$subjid,tchrname:$tchrname},
        success: function(result){
            modal.style.display = "block";
            $("#showdatas").html(result);
        }
    });
}
function adddubject($tchrid,$newdata,$tchrname){
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/update_tchr_class_data/'?>",
        type: "POST",
        data: {tchrid:$tchrid,newdata:$newdata,tchrname:$tchrname},
        success: function(result){
            modal.style.display = "block";
            $("#showdatas").html(result);
        }
    });
}

var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
span.onclick = function() {
  modal.style.display = "none";
  $.ajax({
        url: "<?php echo BASEURL.'/timetable/show_tchrs_class_data/'?>",
        beforeSend:function(){$("#loadingProgressG").show();},
        success: function(result){
            $("#maindata").html(result);
            $("#loadingProgressG").hide();
        }
    });
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/show_tchrs_class_data/'?>",
        beforeSend:function(){$("#loadingProgressG").show();},
        success: function(result){
            $("#maindata").html(result);
            $("#loadingProgressG").hide();
        }
    });
  }
}
</script>