

<?php include "components/header.php"; ?>



<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Time Table for same period time for all class</h3>
    </div>
    <!-- Breadcubs Area End Here -->

    <div class="row gutters-20">
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/class_period">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-red">
                            <i class="flaticon-event-date-and-time-symbol text-red"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Class Period</span></div>
                            <div class="item-title">Click Here</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/subject_wise_teacher">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-calendar-24 text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Subject wise</span></div>
                            <div class="item-title">Teacher</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/preferred_teacher_class">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-controls text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Preferred</span></div>
                            <div class="item-title">Teacher Class</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/manage">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-blue">
                            <i class="flaticon-calendar-20 text-blue"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Time Table</span></div>
                            <div class="item-title">Click Here</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/teacher_wise_timetable">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-yellow">
                            <i class="flaticon-id text-orange"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number">Teacher Wise</div>
                            <div class="item-title">Time Table</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/timetable/day_wise_timetable">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-red">
                            <i class="flaticon-quarantine text-red"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Day Wise</span></div>
                            <div class="item-title">Time Table</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12 d-none">
        <a href="<?php echo BASEURL ?>/schoolinfo/add_stream">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-writing text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Teacher</span></div>
                            <div class="item-title">Management</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12 d-none">
        <a href="<?php echo BASEURL ?>/schoolinfo/add_group">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-blue">
                            <i class="flaticon-american-football text-blue"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Time Table</span></div>
                            <div class="item-title">Sheet</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
    </div>

    <h3 class="font-weight-bold d-none">Time Table for difrent period timing for difrent class</h3>
    <div class="row gutters-20 d-none">
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/schoolinfo/academic_calender">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-cup text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Class Period</span></div>
                            <div class="item-title">Enter</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/schoolinfo/academic_calender">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-cup text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Time Table</span></div>
                            <div class="item-title">Enter</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
        <div class="col-xl-3 col-sm-6 col-12">
        <a href="<?php echo BASEURL ?>/schoolinfo/academic_calender">
            <div class="dashboard-summery-one mg-b-20">
                <div class="row align-items-center">
                    <div class="col-5">
                        <div class="item-icon bg-light-green">
                            <i class="flaticon-cup text-green"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="item-content">
                            <div class="item-number"><span>Time Table</span></div>
                            <div class="item-title">List</div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        </div>
    </div>

</div>


<?php include "components/footer.php"; ?>

