

<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Teacher Wise Time Table</h3>
    </div>
    <!-- Breadcubs Area End Here -->

    
    <div class="card account-settings-box height-auto">
                <div class="card-body">
                    <div class="heading-layout1 mg-b-20">
                    <div class="row w-100">
                        <div class="col-xl-3 col-sm-6 col-12">
                            <select id="subjecttype" class="select2">
                                <option value="mo">Monday</option>
                                <option value="tu">Tuesday</option>
                                <option value="we">Wednesday</option>
                                <option value="th">Thursday</option>
                                <option value="fr">Friday</option>
                                <option value="sa">Saturday</option>
                            </select>
                        </div>
                    </div>
                    </div>
                    
                    
            <div class="artmbody">
                <!-- <div class="artmchldhead arradius">
                    LKG
                </div> -->
                <table id="cldata" class="table display data-table armg10">
                <?php 
                    $this->view2("ajax/allsubjects",$myModel,['wid'=>"11",'tcrid'=>"mo"]);
                ?>

                </table>
                <div class="arclear"></div>
            </div>
                </div>
            </div>
    
</div>

<?php include "components/footer.php"; ?>

<script>
$("#subjecttype").change(function() {
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/day_timetable/'?>", 
        type: "POST",
        beforeSend:function(){$("#loadingProgressG").show();},
        data: {tcrid:$(this).val()},
        success: function(result){
            $("#cldata").html(result);
            $("#loadingProgressG").hide();
        }
    });
});

</script>

