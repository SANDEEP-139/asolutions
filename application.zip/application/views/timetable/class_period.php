

<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Time Table Management</h3>
    </div>
    <!-- Breadcubs Area End Here -->
    
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Class Period</h3>
                </div>
                <div class="dropdown">
                    <button type="button" onclick="addbtn()" class="btn-fill-lmd radius-4 text-light bg-light-sea-green">ADD PERIOD</button>
                </div>
            </div>

            

            <div class="table-responsive">
                <table class="table display data-table">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Period Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="data">
                    <?php
                       $this->view2("ajax/allsubjects",$myModel,['wid'=>"5"]);
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<div id="myModal" class="modal">
  <div class="modal-content">
    <span class="close"><i class="fas fa-times-circle"></i></span>
    <form id="form1" class="form-group">
        <h3 id="heading">New Class Period</h3>
        <input type="hidden" name="subid" id="subid" value=""/>
        <hr>
        <input type="text" id="priod" name="priod" placeholder="Period Name" class="form-control" require>
        <hr>
        <input type="text" id="start" name="start" placeholder="Start Time" class="form-control">
        <hr>
        <input type="text" id="end" name="end" placeholder="End Time" class="form-control">
        <hr>
    </form>
    <button type="submit" id="submit" onclick="submit()" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Save</button>
  </div>
</div>

</div>

<?php include "components/footer.php"; ?>


<script>
function addbtn() {
    modal.style.display = "block";
    $("#submit").html("Save");
    $("#priod").val("");
    $("#start").val("");
    $("#end").val("");
    $("#subid").val("");
}
function updatebtn($id,$name,$stm,$etm) {
    modal.style.display = "block";
    $("#heading").html("Update Class Period");
    $("#submit").html("Update");
    $("#priod").val($name);
    $("#start").val($stm);
    $("#end").val($etm);
    $("#subid").val($id);
}
function deleted($id) {
    $.ajax({
        url: "<?php echo BASEURL.'/timetable/delete_class_period' ?>", 
        type: "POST",
        data: {id:$id},
        beforeSend:function(){$("#loadingProgressG").show();},
        success: function(result){
            modal.style.display = "none";
            $("#data").html(result);
            $("#loadingProgressG").hide();
        }
    });
}
function submit(){
    $priod=$("#priod");
    $start=$("#start");
    $end=$("#end");
    if($priod.val()==""){$priod.css('border','thin solid red');}
    if($start.val()==""){$start.css('border','thin solid red');}
    if($end.val()==""){$end.css('border','thin solid red');}
    if($priod.val()!="" && $start.val()!="" && $end.val()!=""){
        if($("#submit").html()=="Update"){
            $.ajax({
                url: "<?php echo BASEURL.'/timetable/update_class_period/' ?>", 
                type: "POST",
                beforeSend:function(){$("#loadingProgressG").show();},
                data: $("#form1").serialize(),
                success: function(result){
                    modal.style.display = "none";
                    $priod.val("");$start.val("");$end.val("");
                    $("#data").html(result);
                    $("#loadingProgressG").hide();
                }
            });
        }
        else{
            $.ajax({
                url: "<?php echo BASEURL.'/timetable/add_class_period/' ?>", 
                type: "POST",
                data: $("#form1").serialize(),
                beforeSend:function(){$("#loadingProgressG").show();},
                success: function(result){
                    modal.style.display = "none";
                    $priod.val("");$start.val("");$end.val("");
                    $("#data").html(result);
                    $("#loadingProgressG").hide();
                }
            });
        }
    }
}

var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
