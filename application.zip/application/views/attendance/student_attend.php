
<?php include "components/header.php"; ?>

<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area aeroheader2">
        <h3>Attendance Managment</h3>
    </div>
    <!-- Breadcubs Area End Here -->
    
    <div class="card height-auto">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-xl-2 col-lg-6 col-12 arhdng">
                   <h3 class="arm0">Student List</h3>
                </div>
                <div class="col-xl-2 col-lg-6 col-12">
                    <select class="select2" name="class" id="classtype">
                        <?php 
                        $i=0;
                        $myData= $myModel->select_class($this->getSession('userid'));
                        foreach($myData as $myuser):
                            if($i==0){$classidf=$myuser->id;$i++;}
                            if(!empty($viewdata['class'])):if($viewdata['class']==$myuser->id){$sl= "selected";}else{$sl="";};endif;
                            echo '<option value="'.$myuser->id.'"  '.$sl.'>'.$myuser->name.$class.'</option>';
                        endforeach;
                        ?>
                    </select>
                </div>
                <div class="col-xl-2 col-lg-6 col-12">
                    <select class="select2" name="class" id="month">
                    <?php
                        $monthArray = range(0, 11);
                        $finyer= explode("-", finacial_year);
                        foreach ($monthArray as $month) {
                            if($month<6){$yer=$finyer[0];}else{$yer=$finyer[1];}
                            $fdate = month_list[$month];
                            if($fdate==cu_month_name){$select="selected";}else{$select="";}
                            echo '<option value="'. date('n',strtotime($fdate)).','.$yer.'" '.$select.'>'.$yer.' '.$fdate.'</option>';
                            if($fdate==cu_month_name){break;}
                        }
                    ?>
                    </select>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table display data-table">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Student Name</th>
                            <th>Month</th>
                            <th class="text-center">Present</th>
                            <th class="text-center">Absent</th>
                            <th class="text-center">Leave</th>
                            <th class="text-center">View</th>
                        </tr>
                    </thead>
                    <tbody id="studentdata">
                    <?php
                         $this->view2("ajax/allsubjects",$myModel,['wid'=>"16",'clasid'=>$classidf,'status'=>"Active",'all'=>"Select",'month'=>cu_month]);
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>

<?php include "components/footer.php"; ?>

<script>
$("#classtype").change(function() {
    $data=$("#month").val().split(",");
    $.ajax({
        url: "<?php echo BASEURL.'/attendance/studentlist/'?>", 
        type: "POST",
        beforeSend:function(){
            $("#loadingProgressG").show();
        },
        data: {clasid:$(this).val(),status:"Active",month:$data[0],year:$data[1]},
        success: function(result){
            $("#studentdata").html(result);
           $("#loadingProgressG").hide();
        }
    });
});
$("#month").change(function() {
    $data=$(this).val().split(",");
    $.ajax({
        url: "<?php echo BASEURL.'/attendance/student_month_atendence/'?>", 
        type: "POST",
        beforeSend:function(){
            $("#loadingProgressG").show();
        },
        data: {clasid:$("#classtype").val(),status:"Active",month:$data[0],year:$data[1]},
        success: function(result){
            $("#studentdata").html(result);
           $("#loadingProgressG").hide();
        }
    });
});
</script>