<?php include "components/header.php"; ?>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area aeroheader2">
                    <h3>Attendance Management</h3>
                </div>
                <!-- Breadcubs Area End Here -->
            
                <div class="row gutters-20">
                <?php
                    $myData= $myModel->select_class($this->getSession('userid'));
                    $i=0;
                    foreach($myData as $user):
                        $i++;
                        ?>
                        <div class="col-xl-3 col-sm-6 col-12">
                            <div class="data">
                                    <a href="<?php echo BASEURL ?>/attendance/class_attend/<?php echo $user->id; ?>/all">
                                        <div class="core">
                                            <lable><?php echo $user->name; ?></lable>
                                        </div>
                                    </a>
                                <hr />
                                <div class="comen">
                                        <a href="#">
                                            <div class="comenhalf bnhj">
                                                Total Present<label class="text-green textfull">180</label>
                                            </div>
                                        </a>
                                        <a href="#">
                                            <div class="comenhalf">
                                                Total Absent<label class="text-red textfull">180</label>
                                        </div>
                                        </a>
                                    <br class="clear" />
                                </div>
                                <hr />
                                <a href="#">
                                    <div class="comenfull">
                                        Total Leave<label class="text-true-v textfull">180</label>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php
                    endforeach;
                ?>
                </div>
            </div>


<?php include "components/footer.php"; ?>