
<?php
    $myData= $myModel->atendence([$this->getSession('userid')]);
?>
<?php include "components/header.php"; ?>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area aeroheader">
                    <h3>Attendance Management</h3>
                </div>
                <!-- Breadcubs Area End Here -->
                
                <!-- Dashboard Content Start Here -->
                <div class="row gutters-20">
                    <div class="col-12 col-xl-5 col-5-xxxl">
                        <div class="row gutters-20">
                        <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>/attendance/student_attend">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-event text-red"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Student Attend.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-schedule text-magenta"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Staff Attend.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-laptop text-mauvelous"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Student Att. & SMS</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-laptop-1 text-light-sea-green"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Staff Att. & SMS</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-calendar-11 text-martini"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Student Att. Graphs</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-xl-6 col-sm-6 col-12">
                            <a href="<?php echo BASEURL ?>">
                                <div class="dashboard-summery-one mg-b-20">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <div class="item-icon armginauto">
                                                <i class="flaticon-calendar-12 text-orange"></i>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="item-content text-center">
                                                <div class="item-number"><span>Staff Att. Graphs</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-xl-4 col-4-xxxl">
                        <div class="card dashboard-card-five pd-b-20">
                            <div class="card-body pd-b-14">
                                <div class="heading-layout1">
                                    <div class="item-title">
                                        <h3>Attendance Report</h3>
                                    </div>
                                    <div class="dropdown">
                                        <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                                            aria-expanded="false">...</a>

                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-times text-orange-red"></i>Close</a>
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                        </div>
                                    </div>
                                </div>
                                <h6 class="traffic-title">Total Students</h6>
                                <div class="traffic-number">
                                <a href="<?php echo BASEURL ?>/attendance/classwise" class="arblack"><?php echo $myData->tostud ?></a>
                                </div>
                                <div class="traffic-bar">
                                    <div class="direct" data-toggle="tooltip" data-placement="top" title="Direct">
                                    </div>
                                    <div class="search" data-toggle="tooltip" data-placement="top" title="Search">
                                    </div>
                                    <div class="referrals" data-toggle="tooltip" data-placement="top" title="Referrals">
                                    </div>
                                    <div class="social" data-toggle="tooltip" data-placement="top" title="Social">
                                    </div>
                                </div>
                                <div class="traffic-table table-responsive">
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td class="t-title pseudo-bg-Aquamarine">Present</td>
                                                <td>12,890</td>
                                                <td>50%</td>
                                            </tr>
                                            <tr>
                                                <td class="t-title pseudo-bg-blue">Absent</td>
                                                <td>7,245</td>
                                                <td>27%</td>
                                            </tr>
                                            <tr>
                                                <td class="t-title pseudo-bg-yellow">Leave</td>
                                                <td>4,256</td>
                                                <td>8%</td>
                                            </tr>
                                            <tr>
                                                <td class="t-title pseudo-bg-red">Staff Absent</td>
                                                <td>500</td>
                                                <td>7%</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-3 col-3-xxxl">
                        <div class="card dashboard-card-three pd-b-20">
                            <div class="card-body">
                                <div class="heading-layout1">
                                    <div class="item-title">
                                        <h3>Students</h3>
                                    </div>
                                    <div class="dropdown">
                                        <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                                            aria-expanded="false">...</a>

                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-times text-orange-red"></i>Close</a>
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                            <a class="dropdown-item" href="#"><i
                                                    class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="doughnut-chart-wrap">
                                    <canvas id="student-doughnut-chart" width="100" height="300"></canvas>
                                </div>
                                <div class="student-report">
                                    <div class="student-count pseudo-bg-blue">
                                        <h4 class="item-title">Female Students</h4>
                                        <div class="item-number">45,000</div>
                                    </div>
                                    <div class="student-count pseudo-bg-yellow">
                                        <h4 class="item-title">Male Students</h4>
                                        <div class="item-number">1,05,000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Dashboard Content End Here -->

                <h3 class="font-weight-bold">STUDENT REPORTS</h3>
                <div class="row gutters-20">
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-folder text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student Report</span></div>
                                        <div class="item-title">Daily Class Wise</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-user-1 text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student Report</span></div>
                                        <div class="item-title">Monthly Report</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-profile text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number">Student Att. Report</div>
                                        <div class="item-title">Day With Time</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-calendar-19 text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student Leave Report</span></div>
                                        <div class="item-title">Click Here</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>

                <h3 class="font-weight-bold">STAFF REPORTS</h3>
                <div class="row gutters-20">
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-checklists text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Staff Report</span></div>
                                        <div class="item-title">Daily Category Wise</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-folder-2 text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Staff<br>Report</span></div>
                                        <div class="item-title">Monthly Report</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-calendar-9 text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number">Stff Att. Report</div>
                                        <div class="item-title">Day With Time</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-calendar-18 text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Staff Leave Report</span></div>
                                        <div class="item-title">Click Here</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>

                
                <!-- Social Media End Here -->
                <!-- Footer Area Start Here -->
                <?php include "components/copyright.php"; ?>
                <!-- Footer Area End Here -->
            </div>


<?php include "components/footer.php"; ?>

