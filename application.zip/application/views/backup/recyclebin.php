
<?php include "components/header.php"; ?>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area aeroheader2">
                    <h3>Recycle Bin Management</h3>
                </div>
                <!-- Breadcubs Area End Here -->
            
                <div class="row gutters-20">
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-add-group text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Students</span></div>
                                        <div class="item-title">Admission</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-management text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Employee</span></div>
                                        <div class="item-title">List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-4">
                                    <div class="item-icon">
                                        <i class="flaticon-information-3 text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="item-content">
                                        <div class="item-number"><span>Expense</span></div>
                                        <div class="item-title">List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-4">
                                    <div class="item-icon">
                                        <i class="flaticon-employees text-red"></i>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="item-content">
                                        <div class="item-number"><spListan>Students List</span></div>
                                        <div class="item-title">Hostel</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-accounting text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Account List</span></div>
                                        <div class="item-title">Hostel</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-4">
                                    <div class="item-icon">
                                        <i class="flaticon-family text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="item-content">
                                        <div class="item-number"><span>Students</span></div>
                                        <div class="item-title">Registration List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>
            </div>
<?php include "components/footer.php"; ?>