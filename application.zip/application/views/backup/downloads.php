
<?php include "components/header.php"; ?>
<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area aeroheader2">
                    <h3>Downloads Management</h3>
                </div>
                <!-- Breadcubs Area End Here -->
            
                <div class="row gutters-20">
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-advisor text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student</span></div>
                                        <div class="item-title">Info</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-management text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Employee</span></div>
                                        <div class="item-title">List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-4">
                                    <div class="item-icon">
                                        <i class="flaticon-dollar-symbol text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="item-content">
                                        <div class="item-number"><span>Employee</span></div>
                                        <div class="item-title">salary</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-4">
                                    <div class="item-icon">
                                        <i class="flaticon-help-call text-red"></i>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="item-content">
                                        <div class="item-number"><span>Enquiry</span></div>
                                        <div class="item-title">List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-education text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student</span></div>
                                        <div class="item-title">Fee List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-accounting text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Account</span></div>
                                        <div class="item-title">Expense</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-protect text-orange"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Account</span></div>
                                        <div class="item-title">Income</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-calendar-17 text-red"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Attandance</span></div>
                                        <div class="item-title">List</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-lock text-green"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>UserId &</span></div>
                                        <div class="item-title">Password</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                    <a href="<?php echo BASEURL ?>">
                        <div class="dashboard-summery-one mg-b-20">
                            <div class="row align-items-center">
                                <div class="col-5">
                                    <div class="item-icon">
                                        <i class="flaticon-documents-case text-blue"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="item-content">
                                        <div class="item-number"><span>Student TC</span></div>
                                        <div class="item-title">CBSC Board</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                </div>
            </div>
<?php include "components/footer.php"; ?>